package com.abuhatem.taqareer

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.print.PrintAttributes
import android.print.PrintManager
import android.content.Context
import android.view.Gravity
import android.widget.*
import android.text.InputType
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    lateinit var container: LinearLayout
    val navy=Color.rgb(16,24,39); val gold=Color.rgb(212,175,55)
    override fun onCreate(b: Bundle?) { super.onCreate(b); showHome() }
    fun base(): LinearLayout {
        container=LinearLayout(this); container.orientation=LinearLayout.VERTICAL; container.setPadding(22,18,22,22)
        container.setBackgroundColor(navy); return container
    }
    fun title(t:String){ val v=TextView(this); v.text=t; v.textSize=28f; v.setTextColor(Color.WHITE); v.gravity=Gravity.CENTER; v.typeface=Typeface.DEFAULT_BOLD; v.setPadding(4,18,4,24); container.addView(v) }
    fun btn(t:String, click:()->Unit){ val b=Button(this); b.text=t; b.textSize=17f; b.setOnClickListener{click()}; container.addView(b, LinearLayout.LayoutParams(-1,62).apply{setMargins(0,8,0,8)})}
    fun showHome(){
        setContentView(base()); title("تقارير"); 
        val sub=TextView(this); sub.text="تنظيم • دقة • مصداقية"; sub.setTextColor(gold); sub.textSize=16f; sub.gravity=Gravity.CENTER; container.addView(sub)
        Space(this).also{container.addView(it,LinearLayout.LayoutParams(1,28))}
        btn("📄 إنشاء تقرير جديد"){showEditor()}
        btn("📁 أرشيف التقارير"){ Toast.makeText(this,"الأرشيف سيظهر هنا بعد حفظ التقارير",Toast.LENGTH_SHORT).show() }
        btn("🔍 البحث في التقارير"){ Toast.makeText(this,"استخدم البحث بعد حفظ التقارير",Toast.LENGTH_SHORT).show() }
    }
    fun field(h:String, multi:Boolean=false): EditText {
        val e=EditText(this); e.hint=h; e.setTextColor(Color.WHITE); e.setHintTextColor(Color.LTGRAY); e.textSize=16f
        e.inputType=if(multi) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE else InputType.TYPE_CLASS_TEXT
        e.setPadding(18,8,18,8); e.setBackgroundColor(Color.rgb(35,47,66))
        container.addView(e,LinearLayout.LayoutParams(-1, if(multi) 180 else 58).apply{setMargins(0,6,0,6)}); return e
    }
    fun showEditor(){
        setContentView(base()); title("إنشاء تقرير")
        val to=field("إلى: الجهة أو الشخص")
        val subject=field("الموضوع")
        val body=field("نص التقرير",true)
        val author=field("كاتب التقرير")
        val date=field("التاريخ"); date.setText(SimpleDateFormat("yyyy/MM/dd",Locale.getDefault()).format(Date()))
        val sign=field("التوقيع")
        btn("✅ تم — معاينة التقرير"){preview(to.text.toString(),subject.text.toString(),body.text.toString(),author.text.toString(),date.text.toString(),sign.text.toString())}
        btn("↩ رجوع"){showHome()}
    }
    fun preview(to:String,sub:String,body:String,author:String,date:String,sign:String){
        setContentView(base()); title("معاينة التقرير")
        val page=TextView(this); page.setTextColor(Color.BLACK); page.setTextSize(17f); page.setPadding(28,30,28,30); page.gravity=Gravity.RIGHT
        page.setBackgroundColor(Color.WHITE)
        page.text="بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ\n\nإلى: $to\n\nالموضوع: $sub\n\n$body\n\n\nكاتب التقرير: $author\nالتاريخ: $date\nالتوقيع: $sign"
        container.addView(page,LinearLayout.LayoutParams(-1,0,1f))
        btn("🖨️ طباعة"){printReport(page.text.toString())}
        btn("↩ تعديل"){showEditor()}
    }
    fun printReport(text:String){
        val pm=getSystemService(Context.PRINT_SERVICE) as PrintManager
        pm.print("تقرير", ReportAdapter(this,text), PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build())
    }
}
