package com.abuhatem.taqareer
import android.print.*
import android.graphics.*
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.content.Context
class ReportAdapter(val c:Context,val text:String): PrintDocumentAdapter(){
 override fun onLayout(o:PrintAttributes?,n:PrintAttributes?,cs:CancellationSignal?,r:LayoutResultCallback,m:Bundle?){
  if(cs?.isCanceled==true){r.onLayoutCancelled();return}
  r.onLayoutFinished(PrintDocumentInfo.Builder("report.pdf").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(1).build(),true)
 }
 override fun onWrite(p:Array<PageRange>,d:ParcelFileDescriptor,cs:CancellationSignal?,r:WriteResultCallback){
  val pdf=PdfDocument(); val page=pdf.startPage(PdfDocument.PageInfo.Builder(595,842,1).create())
  val paint=Paint(); paint.textSize=16f; paint.color=Color.BLACK; paint.textAlign=Paint.Align.RIGHT
  var y=55f; val x=555f
  for(line in text.split("\n")){page.canvas.drawText(line,x,y,paint);y+=25;if(y>800)break}
  pdf.finishPage(page); pdf.writeTo(java.io.FileOutputStream(d.fileDescriptor)); pdf.close(); r.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
 }
}
